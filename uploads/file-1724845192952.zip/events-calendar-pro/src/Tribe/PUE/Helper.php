<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '14f36d0370e9356a59eed5dfbcb0c7fcaff53cbc';

}
