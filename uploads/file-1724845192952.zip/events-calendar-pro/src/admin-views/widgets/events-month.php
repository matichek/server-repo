<?php
/**
 * Admin View: Month Widget
 *
 * Administration Views cannot be overwritten by default from your theme.
 *
 * See more documentation about our views templating system.
 *
 * @link    http://m.tri.be/1aiy
 *
 * @var \Tribe__Template     $this         Instance of template engine used to render this view.
 *
 * @version 5.5.0
 */

$this->template( 'widgets/components/form' );