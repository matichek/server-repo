<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Templates__Week extends Tribe__Events__Pro__Template_Factory {
	public function __construct() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function get_hour_range() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}


	public static function get_day_range() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function set_global_post( $slug, $name, $data ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}


	public function set_previous_event( $slug, $name, $data ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function manage_sensitive_info( $post ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function header_attributes( $attrs, $current_view ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function setup_view() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function get_week_days() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function has_all_day_events() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function get_event_attributes( $event ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function have_days() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function the_day() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function rewind_days() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function get_current_day() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function day_header_classes() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public static function column_classes() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function event_classes( $classes ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_response() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}