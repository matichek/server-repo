<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Templates__Single_Venue extends Tribe__Events__Pro__Template_Factory {

	public function hooks() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function setup_meta() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function setup_upcoming_events() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function filter_list_nav( $file ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}