<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Recurrence__Navigation {

	public function hook() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function parse_query( $query ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function query_vars( $vars ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function is_past( $past ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function events_attributes( $attributes ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function listview_ajax( $args, $post ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function ajax_event_display( $display ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}