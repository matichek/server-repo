<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Templates__Single_Organizer extends Tribe__Events__Pro__Template_Factory {

	public function setup_upcoming_events() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function remove_list_navigation( $templates, $slug, $name ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}