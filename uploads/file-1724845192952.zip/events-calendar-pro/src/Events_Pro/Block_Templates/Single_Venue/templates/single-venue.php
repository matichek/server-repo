<!-- wp:template-part {"slug":"header","tagName":"header"} /-->
<!-- wp:tec/single-venue {} /-->
<!-- wp:template-part {"slug":"footer","tagName":"footer"} /-->
