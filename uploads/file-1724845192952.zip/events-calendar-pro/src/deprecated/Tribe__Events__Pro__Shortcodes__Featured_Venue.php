<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Shortcodes__Featured_Venue {

	public function __construct( $attributes ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}