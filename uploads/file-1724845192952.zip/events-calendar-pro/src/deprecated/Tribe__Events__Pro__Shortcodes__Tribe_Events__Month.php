<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Shortcodes__Tribe_Events__Month {

	public function __construct( Tribe__Events__Pro__Shortcodes__Tribe_Events $shortcode ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function title_bar() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function next_month_url() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	public function prev_month_url() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}