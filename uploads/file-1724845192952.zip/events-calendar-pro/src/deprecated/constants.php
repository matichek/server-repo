<?php
/**
 * Deprecated constants for the plugin.
 *
 * @since 7.0.1
 */

/**
 * For backwards compatibility.
 *
 * @deprecated 7.0.1
 */
define( 'EVENTS_VIRTUAL_FILE', EVENTS_CALENDAR_PRO_FILE );
