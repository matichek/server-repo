<?php
_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Pro__Shortcodes__This_Week extends \Tribe\Events\Pro\Views\V2\Shortcodes\Shortcode_Tribe_Week {
	public function __construct() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}